// next.config.mjs

export default {
    images: {
      domains: ['i.imgur.com'],
    },
  }
  
