## Soal 1
![gambar 1](1.png)
Menambahkan domain website imgur pada next.config.mjs
## Soal 2
![alt text](2.png)
Membuat komponen baru bernama Gallery yang akan memanggil Profile sebanyak 3x
## Soal 3
![alt text](3.png)

## Soal 4
Kode Sudah Dicommit

## Soal 5
![alt text](4.png)
Tidak ada perbedaan
## Soal 6
![alt text](image.png)

Tidak ada perbedaan
## Soal 7
![alt text](7.png)
## Soal 8
## Soal 9